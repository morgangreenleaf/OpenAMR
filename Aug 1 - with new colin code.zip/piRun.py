#! /usr/bin/python3
try:
    import ftplib
    import time
    import os
    import requests
    import urllib3
    import faulthandler
    import cv2

    faulthandler.enable()
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    # noinspection PyUnresolvedReferences
    import picamera
except Exception as er_cam:
    print(er_cam.__doc__)


def http_request_return_json_or_boolean(file, param, return_data=True):
    while True:
        try:
            _n1 = requests.post(domain + str(file) + ".php", param, timeout=10)
            if _n1.status_code == 200:
                if return_data:
                    return _n1
                elif not return_data:
                    for _i in _n1.text:
                        if _i == "1":
                            return True
                        elif _i != "1":
                            return False
            elif _n1.status_code != 200:
                if not return_data:
                    transactionReset()
        except Exception as e_rt:
            print("http_request_return_json_or_boolean", e_rt)


def setlink(status, filename="setLinkStatus"):
    while True:
        try:
            if http_request_return_json_or_boolean(file=filename, param={"link": status}, return_data=False):
                break
        except Exception as er_setT:
            print("setLinkStatus", er_setT)


def transactionReset():
    while True:
        try:
            if http_request_return_json_or_boolean(file="transactionTerminate", param={}, return_data=False):
                break
        except Exception as e_tra:
            print("transactionReset", e_tra)


def sendImg():
    while True:
        try:
            os.system("scp "+loc+scptarget)
            break
        except Exception as er_img:
            print(er_img)


def conditiontrue():
    captureImg()
    sendImg()
    setlink(2)
    print("Image sent")


def test_mode():
    setlink(2)
    print("testMode")


def main():
    if not os.path.isdir("assets"):
        os.mkdir("assets")
        if not os.path.isdir(imgloc):
            os.mkdir(imgloc)
    while True:
        try:
            for state in http_request_return_json_or_boolean(file="getTestStatus",
                                                             param={}, return_data=True).json()["teststatus"]:
                if int(state["link"]) == 1:
                    conditiontrue()
                elif int(state["link"]) == 3:
                    test_mode()
        except Exception as er_start:
            print("getTestStatus")
            print(er_start)


def captureImg():
    if os.path.exists(loc):
        os.remove(loc)
    try:
        camera = picamera.PiCamera()
        camera.resolution = (2048, 2048)
        camera.framerate = 20
        camera.shutter_speed = 1000000
        camera.iso = 100
        time.sleep(2)
        camera.exposure_mode = 'off'
        camera.capture(loc, format='png')
        camera.close()
        cv2.imwrite(imgloc + "tryimg.png", cv2.resize(cv2.imread(imgloc + "tryimg.png", ), (0, 0), fx=.5, fy=.5))
    except Exception as error:
        print(error.__doc__)


if __name__ == '__main__':
    domain = "http://192.168.0.226:8085/open-amr/php-scripts/"
    scptarget = " ghii-user@192.168.0.226:/var/www/html/open-amr/img"
    imgurl = domain + "img/tryimg.png"
    imgloc, loc = "assets/img/", "assets/img/tryimg.png"
    main()
