#! /usr/bin/env python

from pathlib import Path
import openAMR

raw_dir = Path(r'test/raw')  # raw input images
rgb_dir = Path(r'test/rgb')  # rgb cropped images
discs_dir = Path(r'test/discs')  # discs as text files
discs_rgb_dir = Path(r'test/discs_rgb')  # discs drawn on rgb image
discs_abx_dir = Path(r'test/discs_abx')  # discs abx text as text files
features_dir = Path(r'test/features')  # discs abx text as ORB features
zones_dir = Path(r'test/zones')  # zones as text files
zones_rgb_dir = Path(r'test/zones_rgb')  # zones drawn on rgb image
zones_adj_dir = Path(r'test/zones_adj')  # adjusted zones as text files
zones_rgb_adj_dir = Path(r'test/zones_rgb_adj')  # adjusted zones draw on rgb img
descriptors_dir = Path(r'test/descriptors')  # saved features used in abx_key

for d in [raw_dir,
          rgb_dir,
          discs_dir,
          discs_rgb_dir,
          discs_abx_dir,
          features_dir,
          zones_dir,
          zones_rgb_dir,
          zones_adj_dir,
          zones_rgb_adj_dir]:
    d.mkdir(parents=True, exist_ok=True)

raw = r'01.png'
num = 27

raw_path = raw_dir / raw
rgb_path = rgb_dir / f'{num}.png'
discs_path = discs_dir / f'{num}.txt'
discs_rgb_path = discs_rgb_dir / f'{num}.png'
discs_abx_path = discs_abx_dir / f'{num}.txt'
features_path = features_dir / f'{num}.npz'
zones_path = zones_dir / f'{num}.txt'
zones_rgb_path = zones_rgb_dir / f'{num}.png'
zones_adj_path = zones_adj_dir / f'{num}.txt'
zones_rgb_adj_path = zones_rgb_adj_dir / f'{num}.png'

# crop and convert raw image to rgb for use in all subsequent processing
rgb_img = openAMR.crop_raw(raw_path)
openAMR.save_image(rgb_img, rgb_path)

print(1)
# find and save discs
discs = openAMR.find_discs(rgb_img)
openAMR.save_discs(discs, discs_path)
abx_names = openAMR.search_discs(rgb_img, discs)
print(abx_names)

print(2)

# create dictionary of disc locations
disc_locs = openAMR.get_disc_locations(discs)

# draw discs on rgb image
rgb_discs = openAMR.load_image(rgb_path)
openAMR.draw_discs(rgb_discs, discs)
openAMR.save_image(rgb_discs, discs_rgb_path)
print(3)

# find and save zones
zones = openAMR.find_zones(rgb_img, discs)
openAMR.save_zones(zones, zones_path)

# draw zones on rgb image
rgb_zones = openAMR.load_image(rgb_path)
openAMR.draw_zones(rgb_zones, zones)
openAMR.save_image(rgb_zones, zones_rgb_path)

# print(5)
#
#
# # adjust zone for a given disc number by adjustment_mm
# #   + for increasing
# #   - for decreasing
# disc = 5  # from user interface
# adjustment_mm = 1  # from user interface
# zones = openAMR.load_zones(zones_path)
# zones_adj = openAMR.adjust_zones(zones, disc, adjustment_mm)
# openAMR.save_zones(zones_adj, zones_adj_path)
# print(6)
#
# # create list of zone diameters (mm)
# zone_diams = openAMR.get_zone_diameters(zones_adj)
#
# # draw new adjusted zones
# rgb_zones = openAMR.load_image(rgb_path)
# openAMR.draw_zones(rgb_zones, zones_adj)
# openAMR.save_image(rgb_zones, zones_rgb_adj_path)
#
# print(7)

# # search for abx names from discs
# #   uses abx_key.txt : a text file dictionary of '{dish}_{disc} abx_name'
# #   uses descriptors/{num}.npz : folder of numpy features corresponding to key
# rgb_img = openAMR.load_image(rgb_path)
# discs = openAMR.load_discs(discs_path)
# abx_names = openAMR.search_discs(rgb_img, discs,
#                                  descriptors_dir=descriptors_dir,
#                                  abx_key=r'abx_key.txt')
# openAMR.save_abx_names(abx_names, discs_abx_path)
#
# # save disc features (numpy arrays describing extracted text)
# features = openAMR.find_features(rgb_img, discs)
# openAMR.save_features(features, features_path)
