#! /usr/bin/env python

# todo
#   recalibrate mmppx after discs found; discs = 6mm, dish ~ 80 - 100 mm
#   adjust label positions to avoid overlap
#   add debug flag to save intermediate images

from collections import defaultdict
from pathlib import Path
from PIL import Image
from scipy import stats, ndimage, signal
import numpy as np
import math
import cv2


def median_filter(img, r):
    return median_filter_sp_fp(img, r)


def median_filter_cv(img, r):
    return cv2.medianBlur(img, r)


def median_filter_sp(img, r):
    return ndimage.filters.median_filter(img, size=r)


def median_filter_sp_fp(img, r):
    footprint = mask_discs(r, r, [(r // 2, r // 2, r // 2)])
    return ndimage.filters.median_filter(img, footprint=footprint)


def save_image(img, f):
    Image.fromarray(img).save(f)


def load_image(f):
    return np.array(Image.open(f))


def extract_bg(img, window=10):
    rows, cols = img.shape
    return np.mean(
        (img[0:window, 0:window],
         img[0:window, cols - window:cols],
         img[rows - window:rows, 0:window],
         img[rows - window:rows, cols - window:cols]))


def extract_fg(img, bg=0, epsilon=20):
    boxes = list()
    rows, cols = img.shape
    # binarize
    b_img = img <= (bg + epsilon)
    # background rows
    bg_rows = np.concatenate(([True],
                              b_img.all(axis=1),
                              [True]))
    # edge crossing between bg and fg
    bg_row_edges = np.diff(bg_rows)
    # start, end of each band of fg rows
    fg_row_ranges = np.where(bg_row_edges)[0]
    # pair (start, end) rows
    fg_row_ranges = fg_row_ranges.reshape((-1, 2))
    # background cols in each fg range
    for y0, y1 in fg_row_ranges:
        # background columns
        bg_cols = np.concatenate(([True],
                                  b_img[y0:y1].all(axis=0),
                                  [True]))
        bg_col_edges = np.diff(bg_cols)
        # start, end of each band of fg cols
        fg_col_ranges = np.where(bg_col_edges)[0]
        # pair (start, end) columns
        fg_col_ranges = fg_col_ranges.reshape((-1, 2))
        boxes.extend([((y1 - y0) * (x1 - x0),
                       (y0 + 1, y1 + 1, x0 + 1, x1 + 1))
                      for x0, x1 in fg_col_ranges])

    # extract largest fg object
    size, box = max(boxes)
    (y0, y1, x0, x1) = box
    return y0, y1, x0, x1


def crop(img, bounds):
    y0, y1, x0, x1 = bounds
    return img[y0:y1, x0:x1]


def crop_raw(raw_path):
    raw_img = Image.open(raw_path)
    rgb_img = np.uint8(raw_img)[:, :, :3]
    hsv_img = np.uint8(raw_img.convert('HSV'))
    val_img = hsv_img[:, :, 2]

    bg_val = extract_bg(val_img, window=100)
    fg_box = extract_fg(val_img, bg=bg_val)

    rgb_img = crop(rgb_img, fg_box)
    return rgb_img


def extract_dish(img):
    return ndimage.binary_fill_holes(img > extract_bg(img) + 10)


def resize_dish(img, factor=0.9):
    com = ndimage.measurements.center_of_mass(img)
    m, n = img.shape
    r = int(n / 2 * factor)
    mask = np.zeros((m, n), dtype='bool')
    y, x = map(int, map(round, com))
    b, a = np.ogrid[-y:m - y, -x:n - x]
    c = a * a + b * b <= r * r
    mask[c] = True
    return mask


def resize_discs(discs, factor=0.9):
    return [(x, y, int(round(r * factor))) for x, y, r in discs]


def save_discs(discs, f):
    Path(f).write_text(
        '\n'.join(
            ','.join(map(str, disc))
            for disc in discs))


def load_discs(f):
    discs = []
    lines = Path(f).read_text(encoding='U8').splitlines()
    for line in lines:
        l = line.split(',')
        discs.append((int(l[0]), int(l[1]), float(l[2])))
    return discs


def save_zones(zones, f):
    Path(f).write_text(
        '\n'.join(
            ','.join(map(str, zone))
            for zone in zones.values()))


def load_zones(f):
    zones = {}
    lines = Path(f).read_text(encoding='U8').splitlines()
    for d, line in enumerate(lines):
        l = line.split(',')
        zones[d] = (int(l[0]), int(l[1]), int(l[2]), float(l[3]))
    return zones


def save_contours(contours, f):
    cfile = Path(f).with_suffix('')
    cdict = {str(d): np.squeeze(contour) for d, contour in enumerate(contours)}
    np.savez(cfile, **cdict)


def load_contours(f):
    cfile = Path(f).with_suffix('.npz')
    contours = np.load(cfile)
    return contours


def save_features(features, f):
    ffile = Path(f).with_suffix('')
    fdict = {str(d): np.squeeze(feature) for d, feature in features.items()}
    np.savez(ffile, **fdict)


def load_features(f):
    ffile = Path(f).with_suffix('.npz')
    features = np.load(ffile)
    return features


def save_abx_names(names, f):
    Path(f).write_text(
        '\n'.join(
            ','.join(map(str, name))
            for name in names.values()))


def load_abx_names(f):
    names = {}
    lines = Path(f).read_text(encoding='U8').splitlines()
    for d, line in enumerate(lines):
        l = line.split(',')
        names[d] = (l[0], int(l[1]))
    return names


def get_disc_locations(discs):
    return {int(d + 1): (x, y) for d, (x, y, r) in enumerate(discs)}


def get_zone_diameters(zones):
    return [d for (x, y, r, d) in zones.values()]


def calc_diameter(img):
    com = ndimage.measurements.center_of_mass(img > 0)
    y, x = map(int, map(round, com))

    for i in range(min(img.shape[0] - y, img.shape[1] - x)):
        if img[y + i, x + i] == 0:
            max_y, max_x = y + i, x + i
            break

    for i in range(min(y, x)):
        if img[y - i, x - i] == 0:
            min_y, min_x = y - i, x - i
            break

    dy = max_y - min_y
    dx = max_x - min_x
    d = math.sqrt(dy * dy + dx * dx)
    return d


def draw_discs(img, discs):
    disloc = {}
    for d, disc in enumerate(discs):
        draw_disc(img, disc)
        label = f'Disc {d+1}'
        x, y, r = disc
        disloc[d + 1] = (x, y)
        draw_label(img, x, y, label)
    return disloc



def draw_disc(img, disc):
    x, y, r = disc
    r = int(round(r))
    width = img.shape[1]
    thickness = int(round(width / 600))
    cv2.circle(img, (x, y), r, (255, 0, 0), thickness)


# noinspection PyShadowingNames
def draw_zones(img, zones):
    diam = []
    for z, zone in zones.items():
        draw_zone(img, zone)
        x, y, r, d = zone
        label = f'Disc {z+1}: {d:.2f} mm'
        diam.append(d)
        draw_label(img, x, y, label)
    return diam




def draw_zone(img, zone):
    x, y, r, d = zone
    width = img.shape[1]
    thickness = int(round(width / 600))
    cv2.circle(img, (x, y), r, (255, 0, 0), thickness)


def draw_label(img, x, y, label, font=cv2.FONT_HERSHEY_SIMPLEX, color=(255, 0, 0)):
    width = img.shape[1]
    x_off = x - int(round(width / 20))
    y_off = y - int(round(width / 20))
    font_scale = (width / 1000)
    font_thick = int(round(width / 600))
    cv2.putText(img, label, (x_off, y_off), font, font_scale, color, font_thick)


def draw_contours(img, contours, color=(255, 0, 0), thickness=5):
    cv2.drawContours(img, contours, -1, color, thickness)


# apply threshold to image
#   return contours
def contours_from_thresh(img, thresh):
    _, ti = cv2.threshold(img, thresh, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(ti, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    return contours


# test whether a contour defines a valid disc based on
#   size, circularity, circumference, area
def valid_disc_contour(c, mmppx):
    # moments describe properties of the contour
    # https://docs.opencv.org/3.1.0/d8/d23/classcv_1_1Moments.html
    M = cv2.moments(c)
    area = cv2.contourArea(c) * mmppx * mmppx
    circumference = cv2.arcLength(c, True) * mmppx
    size = M['m00']

    if M['mu02'] > 0:
        circularity = M['mu20'] / M['mu02']
    else:
        circularity = 0
    if area > 0:
        roundness = circumference * circumference / (2 * 3.14159 * area)
    else:
        roundness = 0

    return (0 < size and
            (1 / 1.2) < circularity < 1.2 and
            15 < circumference < 25 and  # 500,   800
            15 < area < 36 and  # 15000, 30000
            roundness < 2.5)  # k


# return x,y coords and radius of disc defined by valid disc contour
def disc_from_contour(c):
    M = cv2.moments(c)
    circ = cv2.arcLength(c, True)
    radiusC = circ / (math.pi * 2)

    x = int(M["m10"] / M["m00"])
    y = int(M["m01"] / M["m00"])
    r = radiusC
    return x, y, r


def find_discs(rgb_img):
    # rgb_img  = Image.open(rgb_path)
    hsv_img = np.uint8(Image.fromarray(rgb_img).convert('HSV'))
    val_img = hsv_img[:, :, 2]

    dish = extract_dish(val_img)
    dish_90 = resize_dish(dish, factor=0.9)
    diam_mm = 90
    diam_px = calc_diameter(dish)
    mmppx = diam_mm / diam_px

    r = round(round(diam_px / diam_mm) * 1.6)
    if r % 2 == 0:
        r += 1

    val_med = median_filter(val_img, int(r))

    val_dish = val_med * dish_90

    discs = _find_discs(val_dish, mmppx)
    return discs


# input   gray/value image
#   brute-force search every threshold value to find max valid disc contours
#   threshold image with mean of threshold values that give max valid discs
# output  discs [(x, y, radius, contour),]
def _find_discs(img, mmppx):
    # brute-force search through all threshold values to find maximum valid discs
    counts = {x: sum(valid_disc_contour(c, mmppx) \
                     for c in contours_from_thresh(img, x))
              for x in range(256)}

    t = defaultdict(list)
    for threshold, count in counts.items():
        t[count].append(threshold)

    max_count = max(t.keys())
    best_thresh = int(sum(t[max_count]) / len(t[max_count]))

    return [disc_from_contour(c)
            for c in contours_from_thresh(img, best_thresh)
            if valid_disc_contour(c, mmppx)]


def threshold_cwt(x, channel='sat'):
    hist = np.histogram(x, bins=range(256), density=True)
    counts = hist[0]
    values = hist[1][:-1]
    peaks = signal.find_peaks_cwt(counts, np.arange(7, 20))  # peak widths
    base = 0.001
    peaks = [p for p in peaks if counts[p] > base]

    if len(peaks) == 1:
        if channel == 'sat':
            t = 0 + 1
        elif channel == 'val':
            t = 255 - 1
    else:
        if channel == 'sat':
            lo = peaks[0] + 4
            hi = peaks[1] - 4
        elif channel == 'val':
            lo = peaks[-2] + 4
            hi = peaks[-1] - 4
        c, tc = min((count, val) for count, val in zip(counts[lo:hi], values[lo:hi]))
        to, _ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        if lo < to and to < hi:
            t = to
        else:
            t = tc

    return t, peaks


def conv_triangle(x, window):
    win = window // 2
    # pad with repeated edge values
    xpad = np.r_[np.repeat(x[0], win), x, np.repeat(x[-1], win)]
    # triangular window
    tri = np.r_[np.arange(1, win + 1), win + 1, np.arange(win, 0, -1)]
    tri = tri / np.sum(tri)
    # convolve
    return np.convolve(xpad, tri, mode='valid')


def threshold_relmax(x):
    hist = np.histogram(x, bins=range(256), density=True)
    counts = conv_triangle(hist[0], 5)
    values = hist[1][:-1]
    vals = [v for c, v in zip(counts, values) if c > 0]
    w = (max(vals) - min(vals)) // 10
    order = int(1.5 * w)
    peaks = [int(p) for p in signal.argrelmax(counts, order=order)[0]]

    to, _ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    if len(peaks) == 1:
        tc = 1
        t = 1
    else:
        lo = peaks[0]
        hi = peaks[1]
        c, tc = min((count, val) for count, val in zip(counts[lo:hi], values[lo:hi]))

        if lo < to and to < hi:
            t = to
        else:
            t = tc

    return t, to, tc, peaks, counts, values


def compare_thresholds_relmax(img, mask):
    x = img[mask > 0]
    t, to, tc, peaks, counts, values = threshold_relmax(x)
    return t, to, tc, peaks, counts, values


def extract_zones_relmax(img, mask):
    x = img[mask > 0]
    t, _, _, _, _, _ = threshold_relmax(x)
    return np.uint8(img > t) * mask


# mask is mask_all (dish_80>0 * discs==0 * labl==0)
# dish is full size dish
# def find_zones(sat, discs, dish, mask):
def find_zones(rgb, discs):
    hsv = np.uint8(Image.fromarray(rgb).convert('HSV'))
    sat = hsv[:, :, 1]
    val = hsv[:, :, 2]

    dish = extract_dish(val)
    diam_mm = 90
    diam_px = calc_diameter(dish)
    mmppx = diam_mm / diam_px
    pxpmm = diam_px / diam_mm

    # rescale sat from bias field
    mask = mask_all(val, discs)
    bias = extract_bias(sat * mask, dish)
    sat_scaled = np.uint8(sat / bias)
    # median_filter rescaled sat
    sat_med = median_filter(sat_scaled, 25)
    # apply mask to sat
    mask *= (sat_med > 0)
    sat_med *= mask
    zone_mask = extract_zones_relmax(sat_med, mask)
    zones = _find_zones(zone_mask, pxpmm, discs)
    return zones


def _find_zones(zone_mask, pxpmm, discs):
    zones = {}
    found = set()
    discs = {d: disc for d, disc in enumerate(discs)}
    height, width = zone_mask.shape

    # set ring values to sample
    #        convert mm to px
    r_min = round(3.5 * pxpmm)
    r_max = round(30.0 * pxpmm)
    r_step = round(1.0 * pxpmm)
    r_disc = round(3.0 * pxpmm)

    for d, disc in discs.items():
        zone_px = r_disc

        # set array dims to multiply w/ circular masks, clipped to image bounds
        x_disc, y_disc, _ = disc

        y_min = max(y_disc - r_max, 0)
        x_min = max(x_disc - r_max, 0)
        y_max = min(y_disc + r_max, height)
        x_max = min(x_disc + r_max, width)

        x_m = x_max - x_min
        y_m = y_max - y_min
        x_c = x_disc - x_min
        y_c = y_disc - y_min

        circ = np.zeros((y_m, x_m), dtype='bool')
        zone_arr = zone_mask[y_min:y_max, x_min:x_max]

        for r in range(r_min, r_max, r_step):
            circ = mask_circ2(circ, x_c, y_c, r, r - 1)
            zone = zone_arr[circ]
            # print(r, zone[zone>0].size * 6, circ[circ>0].size)
            if zone[zone > 0].size * 6 > circ[circ > 0].size:
                if r > r_min:
                    zone_px = r
                    for r2 in range(r - r_step, r):
                        circ = mask_circ2(circ, x_c, y_c, r2, r2 - 1)
                        zone = zone_arr[circ]
                        # print(r2, zone[zone>0].size * 6, circ[circ>0].size)
                        if zone[zone > 0].size * 6 > circ[circ > 0].size:
                            zone_px = r2
                            break
                found.add(d)
                break

        zones[d] = (x_disc, y_disc, zone_px, 2 * zone_px / pxpmm)
        # print(f'zone {d}: {zones[d]}')

    unfound = {d: discs[d] for d in discs.keys() - found}
    if len(unfound):
        overlap = mask_zones(height, width, zones)

    for d, disc in unfound.items():
        zone_px = r_disc

        # set array dims to multiply w/ circular masks, clipped to image bounds
        x_disc, y_disc, _ = disc

        y_min = max(y_disc - r_max, 0)
        x_min = max(x_disc - r_max, 0)
        y_max = min(y_disc + r_max, height)
        x_max = min(x_disc + r_max, width)

        x_m = x_max - x_min
        y_m = y_max - y_min
        x_c = x_disc - x_min
        y_c = y_disc - y_min

        circ = np.zeros((y_m, x_m), dtype='bool')
        zone_arr = zone_mask[y_min:y_max, x_min:x_max]
        over_arr = overlap[y_min:y_max, x_min:x_max]

        for r in range(r_min, r_max, r_step):
            circ = mask_circ2(circ, x_c, y_c, r, r - 1)
            zone = zone_arr[circ]
            over = over_arr[circ]
            if zone[zone > 0].size * 6 > (circ[circ > 0].size - over[over > 0].size):
                if r > r_min:
                    zone_px = r
                    for r2 in range(r - r_step, r):
                        circ = mask_circ2(circ, x_c, y_c, r2, r2 - 1)
                        zone = zone_arr[circ]
                        over = over_arr[circ]
                        if zone[zone > 0].size * 6 > (circ[circ > 0].size - over[over > 0].size):
                            zone_px = r2
                            break
                found.add(d)
                break

        zones[d] = (x_disc, y_disc, zone_px, 2 * zone_px / pxpmm)

    return zones


def mask_circ(m, n, x, y, r1, r0):
    # https://stackoverflow.com/questions/8647024/
    #  how-to-apply-a-disc-shaped-mask-to-a-numpy-array
    mask = np.zeros((m, n), dtype='bool')
    b, a = np.ogrid[-y:m - y, -x:n - x]
    c1 = a * a + b * b <= r1 * r1
    mask[c1] = True
    c0 = a * a + b * b <= r0 * r0
    mask[c0] = False
    return mask


def mask_circ2(mask, x, y, r1, r0):
    m, n = mask.shape
    b, a = np.ogrid[-y:m - y, -x:n - x]
    mask[:] = False
    c1 = a * a + b * b <= r1 * r1
    mask[c1] = True
    c0 = a * a + b * b <= r0 * r0
    mask[c0] = False
    return mask


def mask_disc_scaled(m, n, x, y, r, f):
    mask = np.ones((m, n), dtype='float')
    b, a = np.ogrid[-y:m - y, -x:n - x]
    rc = np.sqrt((a * a) + (b * b)) / r * f
    rc += 1
    return rc


def mask_discs(m, n, discs):
    mask = np.zeros((m, n), dtype='bool')
    for disc in discs:
        x, y, r = disc
        b, a = np.ogrid[-y:m - y, -x:n - x]
        c = a * a + b * b <= r * r
        mask[c] = True
    return mask


def mask_zones(m, n, zones):
    mask = np.zeros((m, n), dtype='bool')
    for zone in zones.values():
        x, y, r, _ = zone
        b, a = np.ogrid[-y:m - y, -x:n - x]
        c = a * a + b * b <= r * r
        mask[c] = True
    return mask


def mask_label(val, discs):
    m, n = val.shape
    disc_mask = mask_discs(m, n, resize_discs(discs, factor=0.9))
    thresh = np.percentile(val[disc_mask > 0], 90)  # thresh < 90% disc max
    mask = (val < thresh)
    return mask


def mask_shadow(val):
    h = np.histogram(val[val > 0], bins=range(256))
    counts = np.log10(h[0] + 1)
    values = h[1][:-1]
    thresh = [value for count, value in zip(counts, values) if count >= 3.1][0]
    mask = (val < thresh)
    return mask


def mask_all(val, discs):
    labl_mask = mask_label(val, discs)
    dish_mask = resize_dish(extract_dish(val), factor=0.8)
    m, n = dish_mask.shape
    disc_mask = mask_discs(m, n, discs)
    temp_mask = (dish_mask > 0) * (disc_mask == 0) * (labl_mask == 0)
    val_med = median_filter(val, 5)
    shdw_mask = mask_shadow(val_med * temp_mask)
    mask = temp_mask * (shdw_mask == 0)
    return mask


def adjust_zones(zones, disc, adjustment_mm):
    x, y, r_px, d_mm = zones[disc]
    d_px = 2 * r_px
    pxpmm = d_px / d_mm
    d_mm += adjustment_mm
    d_px += adjustment_mm * pxpmm
    r_px = int(round(d_px / 2))
    zones[disc] = (x, y, r_px, d_mm)
    return zones


def radial_histogram(img, dish):
    diam = calc_diameter(dish)
    rd = int(math.ceil(diam / 2))

    m, n = dish.shape
    y, x = map(int, map(round, ndimage.measurements.center_of_mass(dish > 0)))
    b, a = np.mgrid[-y:m - y, -x:n - x]
    bb = b * b
    aa = a * a
    r = np.floor(np.sqrt(bb + aa))
    rn = np.arange(0, rd, dtype='uint16')
    prob = np.zeros([rn.size, 255])

    r = r[img > 0]
    img = img[img > 0]

    for ri in rn:
        prob[ri] = np.histogram(img[r == ri], bins=range(256), density=True)[0]

    return prob, rn


def extract_bias(img, dish):
    # threshold inhibited peaks
    t, _ = threshold_cwt(img[img > 0])
    img[img < t] = 0
    # extract growth peak and fit line
    dish = resize_dish(dish, factor=0.8)
    prob, rn = radial_histogram(img, dish)
    r = len(rn)
    peak = np.zeros([rn.size])

    for ri in rn:
        peaks = signal.find_peaks_cwt(prob[ri], np.arange(7, 20))
        peaks = [(prob[ri][p], p) for p in peaks if p > .001]
        if len(peaks):
            peak[ri] = max(peaks)[1]
        else:
            peak[ri] = 0

    # make matrix of radii and peak values for least squares fit
    # peak = peak[peak>0]
    # rn   = rn[peak>0]
    A = np.vstack([rn[peak > 0], np.ones(len(rn[peak > 0]))]).T
    slope, intercept = np.linalg.lstsq(A, peak[peak > 0], rcond=None)[0]
    scale = slope * r / intercept
    # print(scale)

    # make bias field to correct shading
    m, n = img.shape
    y, x = map(int, map(round, ndimage.measurements.center_of_mass(dish > 0)))
    bias = mask_disc_scaled(m, n, x, y, r, scale)

    return bias


def extract_disc(img, disc):
    x, y, r = disc
    return img[int(y - r + 1)
               :int(y + r + 1),
           int(x - r + 1)
           :int(x + r + 1)]


def extract_disc_text(img):
    # create disc mask and 90% disc mask
    m, n = img.shape
    r = m // 2
    r90 = int(0.9 * m) // 2
    msk = np.uint8(mask_discs(m, n, [(r, r, r)]))
    msk90 = np.uint8(mask_discs(m, n, [(r, r, r90)]))
    # fill area around mask with mean value to limit mask edge artifacts
    #   from adaptive threshold
    mean = int(round(np.mean(img[msk > 0])))
    inv = 1 - msk
    fill = (img * msk) + (inv * mean)

    med = median_filter_sp(fill, 3)
    med2 = median_filter_sp(img * msk90, 3)
    vals = med2[msk90 > 0]

    # apply global threshold to find area of disc where text is located
    thresh = int(np.mean(vals) - np.std(vals))
    t, gth = cv2.threshold(med2, thresh, 255, cv2.THRESH_BINARY)

    # apply local threshold to find text edges (still noisy outside text area)
    ath = cv2.adaptiveThreshold(med, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY, 21, 1)

    # combine both thresholded images to get sharp text edges without noise
    txt = (gth == 0) * (ath == 0) * (msk90 > 0)
    txt = np.uint8(ndimage.binary_opening(txt)) * 255
    return txt


def find_features(rgb_img, discs):
    # convert rgb to hsv
    hsv_img = np.uint8(Image.fromarray(rgb_img).convert('HSV'))
    val_img = hsv_img[:, :, 2]

    features = {}
    keypoints = {}

    # create ORB descriptor
    orb = cv2.ORB_create(200,
                         scaleFactor=1.1,
                         nlevels=20,
                         edgeThreshold=10,
                         firstLevel=0,
                         WTA_K=2,
                         patchSize=50)

    for d, disc in enumerate(discs):
        # get val sub-image of disc
        disc_img = extract_disc(val_img, disc)

        # binarize text vs non-text in disc
        disc_txt = extract_disc_text(disc_img)

        # extract features
        keypoints[d], features[d] = orb.detectAndCompute(disc_txt, None)

    return features


def load_descriptors(d):
    d = Path(d)
    descriptors = {}
    for feature_file in d.glob('*.npz'):
        dish = feature_file.stem
        features = load_features(feature_file)
        for disc in features.keys():
            descriptors[f'{dish}_{disc}'] = features[disc]
    return descriptors


def load_identifiers(f):
    lines = Path(f).read_text(encoding='U8').splitlines()
    return {disc: abx for disc, _, abx in map(lambda l: l.partition('  '), lines)}


def distances_to_score(distances, cutoff=11):
    return sum(cutoff - d for d in distances if 0 < d and d < cutoff)


def match_features(features, descriptors_dir):
    # load feature descriptors for previously seen discs
    descriptors = load_descriptors(descriptors_dir)
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = {}

    for disc, feature in features.items():
        distances = {i: [d.distance for d in matcher.match(descriptors[i], feature)]
                     for i in descriptors.keys()}
        scores = {i: distances_to_score(d) for i, d in distances.items()}
        matches[disc] = sorted(((score, i) for i, score in scores.items() if score > 0), reverse=True)

    return matches


def identify_matches(matches, abx_key):
    abx_ids = load_identifiers(abx_key)
    abx_names = {disc: [(abx_ids[name], score) for score, name in match]
                 for disc, match in matches.items()}
    return abx_names


def search_discs(rgb_img, discs, descriptors_dir=r'descriptors', abx_key=r'abx_key.txt'):
    features = find_features(rgb_img, discs)
    matches = match_features(features, descriptors_dir)
    abx_names = identify_matches(matches, abx_key)
    # return only top match
    abx_names = {disc: names[0] if len(names) else ('', 0.0)
                 for disc, names in abx_names.items()}
    return abx_names

# def find_zones(rgb_img, discs):
#  hsv_img     = np.uint8(Image.fromarray(rgb_img).convert('HSV'))
#  sat_img     = hsv_img[:,:,1]
#  val_img     = hsv_img[:,:,2]
#
#  dish        = extract_dish(val_img)
#  dish_80     = resize_dish(dish, factor=0.8)
#  diam_mm     = 90
#  diam_px     = calc_diameter(dish)
#  mmppx       = diam_mm / diam_px
#  pxpmm       = diam_px / diam_mm
#
#  sat_med     = median_filter(sat_img, 25)  #51)
#  val_med     = median_filter(val_img, 25)
#
#  m,n         = dish.shape
#  disc_mask   = mask_discs(m, n, discs)
#  disc90_mask = mask_discs(m, n, resize_discs(discs, factor=0.9))
#  labl_mask   = mask_labl(val_img, disc90_mask, dish)
#  mask        = dish_80 * (disc_mask == 0) * (labl_mask == 0)
#
#  #zone_mask   = extract_zones(sat_med, mask)
#  zone_mask   = extract_zones_cwt(sat_med, mask, channel='sat')
#  shadow_mask = mask_shadow(val_med * (mask > 0))
#  zone_mask   = zone_mask * mask * (shadow_mask == 0)
#  zones       = _find_zones2(zone_mask, pxpmm, discs)
#  return zones

# def compare_thresholds(img, mask, channel='sat'):
#  x         = img[mask>0]
#  to, _     = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#  #tc, peaks = threshold_cwt3(x, channel=channel)
#  tc, peaks = threshold_cwt(x)
#  return (to, tc, peaks)
#
# def extract_zones_cwt(img, mask, channel='sat'):
#  x         = img[mask>0]
#  tc, peaks = threshold_cwt(x, channel=channel)
#
#  if   channel == 'sat':
#    return np.uint8(img > tc) * mask
#  elif channel == 'val':
#    return np.uint8(img < tc) * mask

# def threshold_smoothed(x):
#  hist   = np.histogram(x, bins=range(256), density=True)
#  counts = conv_triangle(hist[0], 5)
#  values = hist[1][:-1]
#  vals   = [v for c,v in zip(counts,values) if c > 0]
#  min_v  = min(vals)
#  max_v  = max(vals)
#  width  = max_v - min_v
#  w      = width // 10
#  peaks  = signal.find_peaks_cwt(counts, np.arange(w, 2*w))
#  indices= [range(max(p-(2*w), min_v), 
#                  min(p+(2*w), max_v))
#            for p in peaks           ]
#  pairs  = [max(zip(counts[i], values[i])) for i in indices]
#  peaks  = [v for c,v in pairs if v > 0.001]
#
#  if len(peaks) == 1:
#    t    = 1
#  else:
#    t, _ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#    #lo   = peaks[0]
#    #hi   = peaks[1]
#    #_, t = min((count,val) for count, val in zip(counts[lo:hi], values[lo:hi]))
#
#  return t, peaks, counts, values
#
# def compare_thresholds_smoothed(img, mask):
#  x      = img[mask>0]
#  to, _  = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#  tc, peaks, counts, values = threshold_smoothed(x)
#  return (to, tc, peaks, counts, values)
#
# def extract_zones_cwt_smoothed(img, mask):
#  x       = img[mask>0]
#  t,_,_,_ = threshold_smoothed(x)
#  return np.uint8(img > t) * mask

# def mask_labl(val, disc_mask, dish_mask):
#  thresh = np.percentile(val[disc_mask > 0], 90)      # thresh < 90% disc max
#  mask   = (val < thresh) * (disc_mask == 0) * (dish_mask > 0)
#  return mask

# def correct_shading(img, factor=0.1):
#  m,n  = img.shape
#  dish = extract_dish(img)
#  dish = resize_dish(dish, factor=0.8)
#  y,x  = map(int, map(round, ndimage.measurements.center_of_mass(dish>0)))
#  diam = calc_diameter(dish)
#  r    = int(math.ceil(diam/2))
#  mask = mask_disc_scaled(m, n, x, y, r, factor)
#  mask*= dish
#  return img * mask

# import os
# def load_descriptors(d):
#  descriptors = {}
#  for feature_file in os.listdir(d):
#    dish     = Path(feature_file).stem
#    features = load_features(Path(d) / feature_file)
#    for disc in features.keys():
#      descriptors[f'{dish}_{disc}'] = features[disc]
#  return descriptors

# def extract_zones(img, mask):
#  t1, ti = cv2.threshold(img[mask>0], 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#  t2, ti = cv2.threshold(img        ,t1, 255, cv2.THRESH_BINARY)
#  return ti

# def threshold_cwt2(x, channel='sat'):
#  hist   = np.histogram(x, bins=range(256), density=True)
#  counts = hist[0]
#  values = hist[1][:-1]
#  peaks  = signal.find_peaks_cwt(counts, np.arange(7, 15)) # peak widths
#  base   = 0.001
#  peaks  = [p for p in peaks if counts[p] > base]
#
#  if len(peaks) == 1:
#    if   channel == 'sat':
#      t  =   0 + 1
#    elif channel == 'val':
#      t  = 255 - 1
#  else:
#    if   channel == 'sat':
#      lo   = peaks[0]  + 4
#      hi   = peaks[1]  - 4
#    elif channel == 'val':
#      lo   = peaks[-2] + 4
#      hi   = peaks[-1] - 4
#    c,tc = min((count,val) for count, val in zip(counts[lo:hi], values[lo:hi]))
#    #to,_ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#    #if lo < to and to < hi:
#    #  t = to
#    #else:
#    #  t = tc
#    t = tc
#
#  return t, peaks

# def find_zones2(rgb_img, sat_med, val_med, discs):
#  hsv_img     = np.uint8(Image.fromarray(rgb_img).convert('HSV'))
#  sat_img     = hsv_img[:,:,1]
#  val_img     = hsv_img[:,:,2]
#
#  dish        = extract_dish(val_img)
#  diam_mm     = 90
#  diam_px     = calc_diameter(dish)
#  mmppx       = diam_mm / diam_px
#  pxpmm       = diam_px / diam_mm
#
#  #sat_med     = median_filter(sat_img, 25)  #51)
#  #val_med     = median_filter(val_img, 25)
#
#  m,n         = dish.shape
#  disc_mask   = mask_discs(m, n, discs)
#  labl_mask   = mask_labl2(val_img, discs)
#  dish_80     = resize_dish(dish, factor=0.8)
#  mask        = dish_80 * (disc_mask == 0) * (labl_mask == 0)
#  shadow_mask = mask_shadow(val_med * (mask > 0))
#  mask        = (shadow_mask == 0) * (mask > 0)
#
#  sat_mask    = extract_zones_cwt(sat_med, mask, channel='sat')
#  val_mask    = extract_zones_cwt(val_med, mask, channel='val')
#  sat_zones   = _find_zones2(sat_mask, pxpmm, discs)
#  val_zones   = _find_zones2(val_mask, pxpmm, discs)
#
#  zones       = {d: max(sat_zones[d], val_zones[d]) 
#                    for d, disc in enumerate(discs)}
#
#  return zones

## todo
##   account for reduced num pixels in circ from dish mask and overlapping zones
##   sanity checks for contrast in sat, val histograms
# def _find_zones(zone_mask, pxpmm, discs):
#  zones = {}
#  height, width = zone_mask.shape
#
#  # set ring values to sample
#  #        convert mm to px
#  r_min  = round( 3.5 * pxpmm)
#  r_max  = round(30.0 * pxpmm)
#  r_step = round( 1.0 * pxpmm)
#  r_disc = round( 3.0 * pxpmm)
# 
#  for d, disc in enumerate(discs):
#    zone_px = r_disc
#
#    # set array dims to multiply w/ circular masks, clipped to image bounds
#    x_disc, y_disc, _ = disc
#
#    y_min = max(y_disc-r_max,      0)
#    x_min = max(x_disc-r_max,      0)
#    y_max = min(y_disc+r_max, height)
#    x_max = min(x_disc+r_max, width )
#
#    x_m  = x_max  - x_min
#    y_m  = y_max  - y_min
#    x_c  = x_disc - x_min
#    y_c  = y_disc - y_min
#
#    circ     = np.zeros((y_m, x_m), dtype='bool')
#    zone_arr = zone_mask[y_min:y_max, x_min:x_max]
#
#    for r in range(r_min, r_max, r_step):
#      circ = mask_circ2(circ, x_c, y_c, r, r-1)
#      zone = zone_arr[circ]
#      if zone[zone > 0].size * 6 > circ[circ > 0].size:
#        if r > r_min:
#          zone_px = r
#          for r2 in range(r - r_step, r):
#            circ = mask_circ2(circ, x_c, y_c, r2, r2-1)
#            zone = zone_arr[circ]
#            if zone[zone > 0].size * 6 > circ[circ > 0].size:
#              zone_px = r2
#              break
#        break
#
#    zones[d] = (x_disc, y_disc, zone_px, 2 * zone_px / pxpmm)
#    #print(f'zone {d}: {zones[d]}')
#
#  return zones

# def threshold_scaled(x):
#  def conv_triangle(x, window):
#    win  = window // 2
#    # pad with repeated edge values
#    xpad = np.r_[np.repeat(x[0], win), x, np.repeat(x[-1], win)]
#    # triangular window
#    tri  = np.r_[np.arange(1, win+1), win+1, np.arange(win, 0, -1)]
#    tri  = tri / np.sum(tri)
#    # convolve
#    return np.convolve(xpad, tri, mode='valid')
#  
#  hist   = np.histogram(x, bins=range(256), density=True)
#  counts = conv_triangle(hist[0], 5)
#  values = hist[1][:-1]
#  peaks  = signal.find_peaks(counts, height=.001, width=3)[0]
#
#  if len(peaks) == 1:
#    t    = 1
#  elif len(peaks) > 2:
#    t, _ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#  else:    
#    lo   = peaks[0]
#    hi   = peaks[1]
#    _, t = min((count,val) for count, val in zip(counts[lo:hi], values[lo:hi]))
#
#  return t, peaks


# def threshold_cwt(x, channel='sat'):
#  hist   = np.histogram(x, bins=range(256))
#  counts = hist[0]
#  values = hist[1][:-1]
#  peaks  = signal.find_peaks_cwt(counts, np.arange(7, 20)) # peak widths
#  base   = sum(counts) // 2000
#  peaks  = [p for p in peaks if counts[p] > base]
#
#  if len(peaks) == 1:
#    if   channel == 'sat':
#      t  =   0 + 1
#    elif channel == 'val':
#      t  = 255 - 1
#  else:
#    if   channel == 'sat':
#      lo   = peaks[0]  + 4
#      hi   = peaks[1]  - 4
#    elif channel == 'val':
#      lo   = peaks[-2] + 4
#      hi   = peaks[-1] - 4
#    c,tc = min((count,val) for count, val in zip(counts[lo:hi], values[lo:hi]))
#    to,_ = cv2.threshold(x, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
#    if lo < to and to < hi:
#      t = to
#    else:
#      t = tc
#  return t, peaks

# import PythonMagick as pm
# import pyvips as pv

# def median_filter_pm(img, r):
#  img_f    = r'img.png'      # write img to file so imagemagick can read it
#  img_med_f= r'img_med.png'  # write img_med to file to numpy can read it
#  Image.fromarray(img).save(img_f)
#  img_med  = pm.Image(img_f)
#  img_med.medianFilter(r)
#  img_med.write(img_med_f)
#  img_med  = np.array(Image.open(img_med_f))
#  return img_med
#
# def median_filter_pv(img, r):
#  img_pv  = pv.Image.new_from_memory(img.flatten().data, *img.shape, 1, 'uchar')
#  img_med = img_pv.rank(r, r, r*r // 2)
#  return np.ndarray(buffer=img_med.write_to_memory(), 
#                    dtype='uint8', 
#                    shape=img.shape)
